frase = input("digite uma frase: ")

frase_n = ""

for e in frase:
    if e != " ":
        frase_n = frase_n + e 

print(frase_n) 
