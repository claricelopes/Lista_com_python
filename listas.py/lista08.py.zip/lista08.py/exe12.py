def replicacao(num):
    for i in range(num + 1):
     print((str(i)  + " ")* i)  

n = int(input("Digite um número: "))

replicacao(n)  