def soma(num1, num2, num3): 
    soma = num1 + num2 + num3
    print(soma)

n1 = int(input("digite um número: "))
n2 = int(input("digite um número: "))
n3 = int(input("digite um número: ")) 

soma(n1, n2, n3)