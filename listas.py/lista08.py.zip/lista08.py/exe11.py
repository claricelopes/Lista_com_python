def comprimento(num1):
    print(len(num1))

n1 = (input("digite um número: ")) 

comprimento(n1) 