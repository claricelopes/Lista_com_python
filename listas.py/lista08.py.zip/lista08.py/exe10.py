def comparacao(num1):
    if num1 > 0:
        print("P")
    else:
        print("N")

n1 = int(input("digite um número: "))

comparacao(n1) 