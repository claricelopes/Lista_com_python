palavra = input("digite uma palavra: ")
 
for i in range(len(palavra) + 1):
    print(palavra[:i])  